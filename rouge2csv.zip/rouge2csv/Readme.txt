Usage:
----------
perl rouge2csv.pl <your results file> <PREFIX>

<your results file> - contains piped results
<PREFIX> - just a prefix to distinguish one set of output from another set

==============================================================
Example Usage:
---------------------
#this will work with the sample file provided
perl rouge2csv.pl sample_results_file.txt TEST